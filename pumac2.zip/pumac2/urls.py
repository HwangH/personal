"""pumac2 URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.9/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""

import os
from django.conf.urls import include, url
from django.conf import settings
from django.contrib import admin, sites, auth
from django.contrib.auth import views as auth_views
from django.views.generic import RedirectView

from registration.views import coach_login
from grading.views import proctor_login
from views import redirect

admin.site.unregister(auth.models.Group)
# admin.site.unregister(sites.models.Site)

urlpatterns = [
    url(r'^$', RedirectView.as_view(pattern_name='coach_login')),
    url(r'^coaches/login', coach_login, {'template_name': 'coach_loginform.html', 'extra_context':{'next':'coaches/profile'}}, name='coach_login'),
    url(r'^coaches/logout', auth_views.logout, {'next_page': '/coaches/login'}, name='coach_logout'),
    # url(r'^coaches/results/$', 'results.views.results', name='results'),
    url(r'^coaches/', include('registration.urls')),
    url(r'^proctors/login', proctor_login, {'template_name': 'proctor_loginform.html', 'extra_context':{'next':'proctors/profile'}}, name='proctor_login'),
    url(r'^proctors/logout', auth_views.logout, {'next_page': '/proctors/login'}, name='proctor_logout'),
    url(r'^proctors/', include('grading.urls')),
    url(r'^proctors/admin/', include(admin.site.urls)),
    url(r'^redirect/$', redirect),
]
