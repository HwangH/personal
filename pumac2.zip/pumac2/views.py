from django.http import HttpResponse, HttpResponseRedirect
from django.contrib.auth.decorators import login_required

from registration.models import Coach
from grading.models import Proctor

@login_required
def redirect(request):
    if Coach.isCoach(request.user):
        return HttpResponseRedirect('/coaches/profile')
    else:
        return HttpResponseRedirect('/proctors/profile')
