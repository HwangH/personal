# Local settings for djmac project (stuff that is unique per deployment).

from settings_common import *

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = True


# while REGISTRATION_LOCKED is False, REGISTRATION_YEAR controls which year
#     new teams are created for
# while REGISTRATION_LOCKED is True, REGISTRATION_YEAR controls which
#     results coaches can see (bump when you want to release results)

REGISTRATION_YEAR = 2016
REGISTRATION_LOCKED = False

DEFAULT_FROM_EMAIL = 'pumac@math.princeton.edu'
EMAIL_HOST = '127.0.0.1'

# Database
# https://docs.djangoproject.com/en/1.9/ref/settings/#databases

# when going production version, make sure to hide all the parameters!
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': 'pumac2_davis',
        'USER': 'jhlu_pumac',
        'PASSWORD': 'YES',
        'HOST': 'localhost',
        'PORT': '',
    }
}

# Make this unique, and don't share it with anybody.
# For random strings, try http://api.wordpress.org/secret-key/1.1/
SECRET_KEY = '^a@j4)@)8#z31roriauxb3(&!un7hns9d^*9ws-_u!y%4hi&74'