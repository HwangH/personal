from registration.models import Coach, School, Team, Participant, TEST_SUBJECTS
import os
from django.db.models import Q
from django.contrib.auth.models import User
from django.contrib.auth.admin import UserAdmin
from django.contrib import admin
from django.http import HttpResponse

#from xlrd import open_workbook, empty_cell
#from xlutils.copy import copy
#from xlwt import Workbook
from django.utils.encoding import smart_str

def get_invoice(modeladmin, request, queryset):
    TEAM_NAME_CELL = (2, 8)
    COACH_NAME_CELL = (2, 9)
    SCHOOL_NAME_CELL = (2, 10)
    SCHOOL_ADDR_1_CELL = (2, 11)
    SCHOOL_ADDR_2_CELL = (2, 12)
    QUANTITY_CELL = (1, 15)
    AMOUNT_CELL = (8, 15)
    SUBTOTAL_CELL = (8, 29)
    TOTAL_CELL = (8, 31)

    UNIT_PRICE = 100

    template_name = os.path.join(os.path.dirname(__file__), 'templates', 'Invoice_Template.xls')
    invoice_template = open_workbook(template_name, formatting_info=True)
    invoice_template_copy = copy(invoice_template)
    invoice_write = invoice_template_copy.get_sheet(0)
    school_name = ''
    coach_name = ''
    team_names_arr = [] 
    coach_addr_1 = ''
    coach_addr_2 = ''
    team_count = 0

    # all teams in this queryset must have the same school!
    for team in queryset:
        school_name = smart_str(team.school.name)
        team_names_arr.append(smart_str(team.name))
        coach = Coach.objects.get(user=team.school.user)
        coach_name = smart_str(coach.name)

        street1 = smart_str(coach.street1)
        street2 = smart_str(coach.street2)
        coach_addr_1 = street1 + " " + street2

        city = smart_str(coach.city)
        state = smart_str(coach.state)
        zip_code = smart_str(coach.zip_code)

        coach_addr_2 = city + ", " + state + " " + zip_code
        team_count += 1
    total = team_count * UNIT_PRICE
    team_names = ', '.join(team_names_arr)

    setOutCell(invoice_write, TEAM_NAME_CELL, team_names)
    setOutCell(invoice_write, COACH_NAME_CELL, coach_name)
    setOutCell(invoice_write, SCHOOL_NAME_CELL, school_name)
    setOutCell(invoice_write, SCHOOL_ADDR_1_CELL, coach_addr_1)
    setOutCell(invoice_write, SCHOOL_ADDR_2_CELL, coach_addr_2)
    setOutCell(invoice_write, QUANTITY_CELL, smart_str(team_count))
    setOutCell(invoice_write, AMOUNT_CELL, smart_str(total))
    setOutCell(invoice_write, SUBTOTAL_CELL, smart_str(total))
    setOutCell(invoice_write, TOTAL_CELL, smart_str(total))

    # save it to a stream
    fname_prefix = 'PUMaC_Invoice_2014_'
    fname = fname_prefix + school_name + '.xls'
    response = HttpResponse(mimetype="application/ms-excel")
    response['Content-Disposition'] = 'attachment; filename=%s' % fname
    invoice_template_copy.save(response)
    return response


# code found on stackoverflow to preserve style
# http://stackoverflow.com/questions/3723793/preserving-styles-using-pythons-xlrd-xlwt-and-xlutils-copy
def _getOutCell(outSheet, colIndex, rowIndex):
    """ HACK: Extract the internal xlwt cell representation. """
    row = outSheet._Worksheet__rows.get(rowIndex)
    if not row: return None

    cell = row._Row__cells.get(colIndex)
    return cell

def setOutCell(outSheet, pair, value):
    """ Change cell value without changing formatting. """
    col = pair[0]
    row = pair[1]
    # HACK to retain cell style.
    previousCell = _getOutCell(outSheet, col, row)
    # END HACK, PART I

    outSheet.write(row, col, value)

    # HACK, PART II
    if previousCell:
        newCell = _getOutCell(outSheet, col, row)
        if newCell:
            newCell.xf_idx = previousCell.xf_idx
    # END HACK
