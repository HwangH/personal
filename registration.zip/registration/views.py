import smtplib
import csv
from datetime import datetime
from random import sample
from django.http import HttpResponseForbidden
from django.shortcuts import render_to_response
from django.template import RequestContext, Template, Context, loader
from django.http import HttpResponse, HttpResponseRedirect
from django.core.urlresolvers import reverse
from django.core.mail import send_mail
from django.conf import settings
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import PasswordChangeForm
from django.contrib.auth.views import login

from models import Coach, School, Team
from forms import UserCreationForm, CoachForm, SchoolForm, TeamForm, PassResetForm

COACH_LOGIN = '/coaches/login'

def _nav(user):
    """
    Returns a dictionary of authorized schools and teams to edit.
    """
    if not user.is_authenticated():
        # don't call this function with an anonymous user
        return

    nav = {}
    if Coach.authorized(user).count() > 0:
        # profile was filled out
        nav['school_auth'] = True
        nav['schools'] = []
        for school in School.authorized(user).all():
            # a school exists
            nav['schools'] += [{
                                    'name': str(school),
                                    'id': school.id,
                                    'team_auth': school.is_writable(user),
                                    'teams': Team.authorized(user).filter(school=school)
                                }]
    return nav

# check that a user is a coach; if they aren't, return an error
def is_coach(user):
    return Coach.isCoach(user)
def coach_error():    
    error = '<h1>Forbidden</h1><p>You do not have coach privileges.</p>'
    return HttpResponseForbidden(error)    


def coach_login(request, **kwargs):
    if request.user.is_authenticated() and is_coach(request.user):
        return HttpResponseRedirect(reverse(profile))
    else:
        return login(request, **kwargs)



@login_required(login_url=COACH_LOGIN)
def index(request):
    if is_coach(request.user):
        return HttpResponseRedirect(reverse(profile))
    else:
        coach_error()

def register(request):
    if request.method == "POST":
        user_form = UserCreationForm(request.POST)
        coach_form = CoachForm(request.POST)
        # print "post"
        if user_form.is_valid() and coach_form.is_valid():
            user = user_form.save()
            coach = coach_form.save(commit=False)
            coach.user = user
            coach.save()
            messages.success(request, 'Thank you for registering.')
            return HttpResponseRedirect(reverse(profile))
        messages.error(request, 'There were errors. Please try again.')
    else:
        user_form = UserCreationForm()
        coach_form = CoachForm()


    return render_to_response('user_coach_form.html', {
        'user_form': user_form,
        'coach_form': coach_form,
        'formtitle': "Coach User Registration Form"
    }, context_instance=RequestContext(request))

def _add_progress_message(request):
    if settings.REGISTRATION_LOCKED:
        msg = 'Registration is currently locked. Feel free to send us an email if you have any problems.'
    elif Coach.authorized(request.user).count() == 0:
        msg = 'We need your contact information before you can register teams.'
    elif School.authorized(request.user).filter(competition_year=settings.REGISTRATION_YEAR).count() == 0:
        try:
            school = School.authorized(request.user)[0]
            school_url = reverse(new_school, kwargs={'id': school.id})
        except IndexError:
            school_url = reverse(new_school)
        msg = 'You have no schools registered for this year. <a href="{0}">Click here to add one</a>.'.format(school_url)
    else:
        num_teams = Team.authorized(request.user).filter(school__competition_year=settings.REGISTRATION_YEAR).count()
        msg = 'You currently have {0} teams in the process of registering. Click an "Add Team" link above to add one.'.format(num_teams)
    messages.info(request, msg)

@login_required(login_url=COACH_LOGIN)
def profile(request):
    if not is_coach(request.user):
        return coach_error()
    coach = Coach.authorized(request.user).get()

    if request.method == "POST":
        form = CoachForm(request.POST, instance=coach)
        if form.is_valid():
            # we can assume that the profile is attached to our user
            form.save()
            messages.success(request, 'Profile updated successfully.')
            return HttpResponseRedirect(reverse(profile))
    else:
        form = CoachForm(instance=coach)
        _add_progress_message(request)

    return render_to_response('coach_form.html', {
        'nav': _nav(request.user),
        'formtitle': 'Profile',
        'form': form,
    }, context_instance=RequestContext(request))

@login_required(login_url=COACH_LOGIN)
def change_password(request):
    if not is_coach(request.user):
        return coach_error()
    if request.method == "POST":
        form = PasswordChangeForm(request.user, request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Password changed.')
            return HttpResponseRedirect(reverse(profile))
    else:
        form = PasswordChangeForm(request.user)

    return render_to_response('coach_form.html', {
        'nav': _nav(request.user),
        'formtitle': 'Change Password',
        'form': form,
    }, context_instance=RequestContext(request))

@login_required(login_url=COACH_LOGIN)
def new_school(request, id=None):
    if not is_coach(request.user):
        return coach_error()
    "If id is not None, prepopulate with that school's values."

    if request.method == "POST":
        form = SchoolForm(request.user, request.POST)
        # the new school's coach is automatically this user
        form.instance.coach = request.user
        if form.is_valid():
            form.save()
            messages.success(request, 'School/Organization added successfully.')
            return HttpResponseRedirect(reverse(edit_school, kwargs={'id': form.instance.id}))
    else:
        school = None
        if id is not None:
            try:
                school = School.authorized(request.user).get(id=id)
            except School.DoesNotExist:
                messages.error(request, 'Could not copy that school.')
        # this does a copy because the id and year are not passed through the form
        form = SchoolForm(request.user, instance=school)

    return render_to_response('coach_form.html', {
        'nav': _nav(request.user),
        'formtitle': 'New School/Organization',
        'form': form,
    }, context_instance=RequestContext(request))

def _add_copy_school_message(request, school_id):
    messages.info(request,
            'This school is from a different year. '
            'To register teams for this year, please '
            '<a href="' + reverse(new_school, kwargs={'id': school_id}) + '">'
            'create a new school</a>.')

@login_required(login_url=COACH_LOGIN)
def edit_school(request, id):
    if not is_coach(request.user):
        return coach_error()

    try:
        school = School.authorized(request.user).get(id=id)
    except School.DoesNotExist: # cannot edit a new school
        return HttpResponseRedirect(reverse(new_school))

    if request.method == "POST":
        form = SchoolForm(request.user, request.POST, instance=school)
        if form.is_valid():
            form.save()
            messages.success(request, 'School/Organization updated successfully.')
            return HttpResponseRedirect(reverse(edit_school, kwargs={'id': id}))
    else:
        form = SchoolForm(request.user, instance=school)
    if school.competition_year != settings.REGISTRATION_YEAR and not settings.REGISTRATION_LOCKED:
        _add_copy_school_message(request, school.id)
    else:
    	_add_progress_message(request)

    return render_to_response('coach_form.html', {
        'nav': _nav(request.user),
        'formtitle': 'Updating School/Organization',
        'form': form,
    }, context_instance=RequestContext(request))

@login_required(login_url=COACH_LOGIN)
def new_team(request, school_id):
    if not is_coach(request.user):
        return coach_error()

    try:
        school = School.authorized(request.user).get(id=school_id)
    except School.DoesNotExist:
        return HttpResponseRedirect(reverse(index))

    if request.method == "POST":
        form = TeamForm(request.user, school, data=request.POST)
        if form.is_valid():
            team = form.save(True)
            messages.success(request, 'Team added successfully.')
            return HttpResponseRedirect(reverse(edit_team, kwargs={'school_id': school_id, 'id': team.id}))
    else:
        form = TeamForm(request.user, school)

    return render_to_response('teamform.html', {
        'nav': _nav(request.user),
        'formtitle': 'New Team',
        'teamform': form,
    }, context_instance=RequestContext(request))

def _add_status_message(request, status):
    level = messages.SUCCESS
    if status == 'pending':
        level = messages.INFO
        message = "We will review this team and contact you to request payment or inform you of any necessary waitlisting."
    if status == 'accepted':
        message = "Your team is accepted into the competition pending received payment. <a href=\"/info/registration/\">More info</a>."
    if status == 'active':
        message = "Thank you for participating. We look forward to seeing your team at the competition."
    if status == 'power':
        message = "Thank you for participating. We look forward to seeing your power round submission."
    if status == 'waitlisted':
        level = messages.INFO
        message = "This team has been waitlisted. We will let you know if there is a chance for this team to enter the competition."
    if status == 'denied':
        level = messages.ERROR
        message = "We are very sorry, but we are unable to accept this team into the competition this year."
    messages.add_message(request, level, message)

@login_required(login_url=COACH_LOGIN)
def edit_team(request, school_id, id):
    if not is_coach(request.user):
        return coach_error()

    try:
        school = School.authorized(request.user).get(id=school_id)
        team = Team.authorized(request.user).get(school=school,id=id)
    except School.DoesNotExist, Team.DoesNotExist:
        return HttpResponseRedirect(reverse(index))

    if request.method == "POST":
        save_team = not team.finalized
        if request.POST.has_key('finalize'):
            if not team.finalized:
                team.finalized = True
                team.finalized_time = datetime.now()
                top_teams = (Team.objects.filter(school__competition_year = settings.REGISTRATION_YEAR-1,
                    division='A',).order_by('-weighted_score')[:10])
                additional_teams = 0
                for top_team in top_teams:
                    if team.school == top_team.school:
                        additional_teams += 1

                # if (Team.objects.filter(finalized=True, status='active', school=team.school,
                #     school__competition_year=settings.REGISTRATION_YEAR).count() >= 2 + additional_teams):
                #     _send_too_many_teams_email(team)
                #
                # elif team.division=='C':
                #     if (Team.objects.filter(finalized=True, status='active',
                #         school__competition_year=settings.REGISTRATION_YEAR,
                #         division='C').count() >= 20):
                #         _send_power_rejection_email(team)
                #     else:
                #         _send_power_confirmation_email(team)
                # elif (team.school.coach.coach.country != 'United States' and
                #         Team.objects.filter(finalized=True, status='active',
                #         school__coach__coach__country=team.school.coach.coach.country,
                #         entry='main', school__competition_year=settings.REGISTRATION_YEAR).count() >=12 ):
                #     _send_too_many_teams_email(team)
                # elif (Team.objects.filter(finalized=True, status='active',
                #         school__competition_year=settings.REGISTRATION_YEAR,
                #         entry='main').count() > settings.TEAM_NUM_LIMIT):
                #     _send_waitlist_email(team)
                # else:
                #     if team.participant_count == 8:
                #         _send_registration_confirmation_email(team)
                #     else:
                #         _send_waiting_on_student_email(team)
        form = TeamForm(request.user, school, data=request.POST, instance=team)
        if form.is_valid():
            form.save(commit_team=save_team)
            if save_team:
                messages.success(request, 'Team updated successfully.')
            else:
                messages.success(request, 'Students updated successfully.')
            return HttpResponseRedirect(reverse(edit_team, kwargs={'school_id': school_id, 'id': id}))
    else:
        if school.competition_year != settings.REGISTRATION_YEAR:
            _add_copy_school_message(request, school_id)
        elif team.finalized:
            _add_status_message(request, team.status)
        elif team.is_writable(request.user):
            messages.info(request, 'This team has not been finalized. When you are ready to enter the competition, click "Submit Application" at the bottom of the page.')
        elif team.status is 'accepted':
            messages.success(request, "YAYAYYAYAYAY!")
        form = TeamForm(request.user, school, instance=team)

    return render_to_response('teamform.html', {
        'nav': _nav(request.user),
        'formtitle': 'Updating Team',
        'teamform': form,
        'can_finalize': not team.finalized and not settings.REGISTRATION_LOCKED,
    }, context_instance=RequestContext(request))



# TODO: Should we remove the below?

def _send_too_many_teams_email(team):
    t = loader.get_template('too_many_teams_email.txt')
    coach = Coach.objects.get(user=team.school.coach)
    date = settings.POWER_ROUND_DATE
    c = Context({'coach':coach,
                 'team':team,
                 'date':date,})
    send_mail('PUMaC too many teams', t.render(c), to=[coach.email, 'pumac.staff@gmail.com'])
    #team.status='denied'
    #team.save()

def _send_power_rejection_email(team):
    t = loader.get_template('power_rejection_email.txt')
    coach = Coach.objects.get(user=team.school.coach)
    date = settings.POWER_ROUND_DATE
    c = Context({'coach':coach,
                 'team':team,
                 'date':date,})
    send_mail('PUMaC power round rejection', t.render(c), to=[coach.email, 'pumac.staff@gmail.com'])
   # team.status='denied'
   # team.save()

def _send_power_confirmation_email(team):
    t = loader.get_template('power_confirmation_email.txt')
    coach = Coach.objects.get(user=team.school.coach)
    date = settings.POWER_ROUND_DATE
    c = Context({'coach':coach,
                 'team':team,
                 'date':date,})
    send_mail('PUMaC power round confirmation', t.render(c), to=[coach.email, 'pumac.staff@gmail.com'])
   # team.status='active'
   # team.save()

def _send_waiting_on_student_email(team):
    t = loader.get_template('waiting_on_student_email.txt')
    coach = Coach.objects.get(user=team.school.coach)
    date = settings.POWER_ROUND_DATE
    c = Context({'coach':coach,
                 'team':team,})
    send_mail('PUMaC finalization error', t.render(c), to=[coach.email, 'pumac.staff@gmail.com'])

def _send_waitlist_email(team):
    t = loader.get_template('waitlist_email.txt')
    coach = Coach.objects.get(user=team.school.coach)
    c = Context({'coach':coach,
                 'team':team})
    send_mail('PUMaC waitlist', t.render(c), to=[coach.email, 'pumac.staff@gmail.com'])
   # team.status='waitlisted'
   # team.save()

def _send_registration_confirmation_email(team):
    t = loader.get_template('base_email.txt')
    coach = Coach.objects.get(user=team.school.coach)
    unfinished_teams = Team.objects.filter(finalized=False,
            school__competition_year=settings.REGISTRATION_YEAR, school=team.school).count() - 1
    c = Context({'coach':coach,
        'date': settings.COMPETITION_DATE,
        'unfinished_teams_num': unfinished_teams,
        'team': team})
    send_mail('PUMaC registration confirmation', t.render(c), to=[coach.email, 'pumac.staff@gmail.com'])
   # team.status='active'
   # team.save()


def _send_reset_email(to_address, username, reset_code):
    msg = """Your password at https://pumac.princeton.edu/coaches/ has been reset. If you did not request this, and this email is unexpected, please let us know.

Here is your new login information: \nUsername: {0}\nPassword: {1}

We recommend changing this password. You can do so at https://pumac.princeton.edu/coaches/changepassword/

If you have any questions or concerns, feel free to email us by replying to this email.""".format(username, reset_code)
    send_mail('PUMaC Password Reset', msg, settings.EMAIL_HOST_USER, [to_address], fail_silently=False)

def reset_password(request):
    if request.method == "POST":
        form = PassResetForm(request.POST)
        if form.is_valid():
            try:
                email = form.cleaned_data['email']
                coach = Coach.objects.get(email=email)
                new_pass = ''.join(sample("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789", 10))
                try:
                    _send_reset_email(email, coach.user.username, new_pass)
                    coach.user.set_password(new_pass)
                    coach.user.save()
                    messages.success(request, "Your password was reset. You should receive an email " + 
                                              "with your new password. Let us know at " + 
                                              "pumac.staff@gmail.com if there are any problems.")
                except Exception as e:
                    messages.error(request, "There was an error sending your password reset email, please let us know at pumac.staff@gmail.com. Error: "+ str(e))
            except Coach.DoesNotExist: # cannot find a corresponding coach
                messages.error(request, "We couldn't find a coach account with that email address. Please try again.")

    else:
        form = PassResetForm()

    return render_to_response('coach_form.html', {
        'form': form,
        'formtitle': 'Reset your password',
    }, context_instance=RequestContext(request))

# test function for sending emails
def send_email(request):
    error = ('<h1>Forbidden</h1><p>You do not have staff '
            'privileges.</p>')

    # make this username your username
    if request.user.username != 'eugenet' and request.user.username != 'dxue@':
	return HttpResponseForbidden(error)

    try:
        _send_test_email()
    except Exception: #smtplib.SMTPException:
        messages.error(request, "error")

    return render_to_response('coach_form.html', {
        'form': null,
        'formtitle': 'Test',
        }, context_instance=RequestContext(request))

def test_send_email(request):
    try:
        _send_test_email()
    except Exception:
        return HttpResponseForbidden('<h1>Error sending email</h1>')
    
    return HttpResponseForbidden('<h1>Success</h1>')

def _send_test_email():
    # settings.EMAIL_HOST_USER
    send_mail('PUMaC Password Reset', 'test', 'pumac.staff@gmail.com', ['ryan.mccaffrey.42@gmail.com'], fail_silently=False)

def intl_teams(request):
    # Create the HttpResponse object with the appropriate CSV header.
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="somefilename.csv"'

    # The data is hard-coded here, but you could load it from a database or
    # some other source.
    csv_data = (
        ('First row', 'Foo', 'Bar', 'Baz'),
        ('Second row', 'A', 'B', 'C', '"Testing"', "Here's a quote"),
    )

    t = loader.get_template('my_template_name.txt')
    c = Context({
        'data': csv_data,
    })
    response.write(t.render(c))
    return render_to_response('base.html', {
        }, context_instance=RequestContext(request))
