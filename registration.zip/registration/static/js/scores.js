$(document).ready(function(){
	$("input:submit").click(function(event){
		params="dataonly=on&test="+$("select[name=test]").val()+"&max="+$("input:text[name=max]").val()+"&team="+$("select[name=team]").val();
		if ($("input:checkbox[name=stats]").attr('checked')) params += "&stats=on";
		$("div#data").load("scores.php",params,function(){
			if ($("#stats").length) $.plot($("#stats"),eval($("#stats").html()),{
				yaxis:{min:0,max:100},
				y2axis:{min:0,max:40},
				xaxis:{min:0,max:10,ticks:[[1,"Q1"],[2,"Q2"],[3,"Q3"],[4,"Q4"],[5,"Q5"],
					[6,"Q6"],[7,"Q7"],[8,"Q8"],[9,"Score"]]},
				lines:{show:false},
				bars:{show:true,align:"center",barWidth:.8},
			});
		});
		event.preventDefault();
	});
});
