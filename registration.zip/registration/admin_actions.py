import csv
import datetime
from django.utils.encoding import smart_str
from django.http import HttpResponse

from models import Coach, School, Team, Participant, TEST_SUBJECTS





# actions for our models (e.g. exporting CSVs and generating invoices)

def get_invoice(modeladmin, request, queryset):
    return invoice.get_invoice(modeladmin, request, queryset)
get_invoice.short_description = u"Generate Invoice"

def export_teams(modeladmin, request, queryset):
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename=teams_' + datetime.date.today().strftime("%Y-%m-%d") + ".csv"
    writer = csv.writer(response, csv.excel)
    response.write(u'\ufeff'.encode('utf8')) # BOM (optional...Excel needs it to open UTF-8 file properly)
    writer.writerow([
        smart_str(u"Name"),
        smart_str(u"School"),
        smart_str(u"Coach Email"),
        smart_str(u"Status"),
        smart_str(u"Division"),
        smart_str(u"Nationality"),
        smart_str(u"Team Type"),
        smart_str(u"Regional Team Explanation"),
        smart_str(u"Participant Count"),
        smart_str(u"Half Team Flag"),
        smart_str(u"Team Achievement"),
    ])
    for obj in queryset:
        writer.writerow([
            smart_str(obj.name),
            smart_str(obj.school),
            smart_str(Coach.objects.get(user=obj.school.coach).email),
            smart_str(obj.status),
	        smart_str(obj.division),
            smart_str(obj.nationality),
            smart_str(obj.teamtype),
            smart_str(obj.regional_team_explanation),
            smart_str(obj.participant_count),
            smart_str(obj.halfteamflag),
            smart_str(obj.team_achievement),
        ])

    return response
export_teams.short_description = u"Export CSV of Teams"

# For each team, list the number of each type of test they are taking
def get_tests_per_team(modeladmin, request, queryset):
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename=testsPerTeam.csv'
    writer = csv.writer(response, csv.excel)
    response.write(u'\ufeff'.encode('utf8')) # BOM (optional...Excel needs it to open UTF-8 file properly)

    col_names = [ smart_str(u"Team Name") ]
    for subject in TEST_SUBJECTS:
        col_names.append(smart_str(subject[1]))
    writer.writerow(col_names)

    for team in queryset:
        subject_num = {} # Dictionary mapping test types to number the team is signed up to take
        for subject in TEST_SUBJECTS:
            subject_num[subject[0]] = 0

        try:
            participants = Participant.objects.filter(team=team)
        except Participant.DoesNotExist:
            participants = []

        for participant in participants:
            subject_num[participant.subject1] += 1
            subject_num[participant.subject2] += 1
        row = [ smart_str(team.name) ]
        for subject in TEST_SUBJECTS:
            row.append(smart_str(subject_num[subject[0]]))
        writer.writerow(row)

    return response
get_tests_per_team.short_description = u"Get teams' test types"

def export_participants(modeladmin, request, queryset):
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename=participants.csv'
    writer = csv.writer(response, csv.excel)
    response.write(u'\ufeff'.encode('utf8'))

    writer.writerow([
        smart_str(u"Name"),
        smart_str(u"Team"),
    ])

    for obj in queryset:
        writer.writerow([
            smart_str(obj.name),
            smart_str(obj.team),
        ])

    return response
export_participants.short_description = u"Export CSV of Participants"

def export_csv_top10individual(modeladmin, request, queryset):
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename=top10individual.csv'
    writer = csv.writer(response, csv.excel)
    response.write(u'\ufeff'.encode('utf8'))
    sortedindividuals = sorted(queryset, key=lambda x: x.weighted_score, reverse = True)
    top10individuals = sortedindividuals[:10]

    for x in range (1, 10):
        writer.writerow([smart_str(u"INDIVIDUAL0"+str(x)), smart_str(top10individuals[x-1].name), smart_str(top10individuals[x-1].weighted_score), smart_str(top10individuals[x-1].team.division)])
    writer.writerow([smart_str(u"INDIVIDUAL10"), smart_str(top10individuals[x-1].name), smart_str(top10individuals[x-1].weighted_score), smart_str(top10individuals[x-1].team.division)])
    
    return response
export_csv_top10individual.short_description = u"Export CSV of top 10 individual"
