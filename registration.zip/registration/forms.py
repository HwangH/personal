from django import forms
from django.conf import settings
from django.forms.formsets import formset_factory
from django.forms.models import model_to_dict, modelformset_factory
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError

from models import Coach, School, Team, Participant, HALFTEAMFLAG, GRADE_CHOICES

class UserCreationForm(forms.ModelForm):
    """
    django.contrib.auth.forms.UserCreationForm with a different username regex.
    """
    username = forms.RegexField(label="Username", max_length=30, regex=r'^[\w.\-_]+$',
        help_text = "Required. 30 characters or fewer. Letters, digits and . - _ only.",
        error_messages = {'invalid': "Username may contain only letters, numbers and . - _ characters."})
    password1 = forms.CharField(label="Password", widget=forms.PasswordInput)
    password2 = forms.CharField(label="Password confirmation", widget=forms.PasswordInput,
        help_text = "Enter the same password as above, for verification.")

    class Meta:
        model = User
        fields = ('username',)

    def clean_username(self):
        username = self.cleaned_data["username"]
        try:
            User.objects.get(username=username)
        except User.DoesNotExist:
            return username
        raise forms.ValidationError("A user with that username already exists.")

    def clean_password2(self):
        MIN_PASS_LENGTH = 8

        password1 = self.cleaned_data.get("password1", "")
        if len(password1) < MIN_PASS_LENGTH:
            raise forms.ValidationError("Password must be at least %d characters." % (MIN_PASS_LENGTH))
        password2 = self.cleaned_data["password2"]

        if password1 != password2:
            raise forms.ValidationError("The two password fields didn't match.")
        return password2

    def save(self, commit=True):
        user = super(UserCreationForm, self).save(commit=False)
        user.set_password(self.cleaned_data["password1"])
        user.save()

        # create a coach object associated with this user
        try:
            coach = Coach.authorized(user).get()
        except:
            coach = Coach.objects.create(user=user)
        
        return user

class CoachForm(forms.ModelForm):
    """
    A form for a coach's profile
    """
    phone_number = forms.RegexField(label="Phone Number", regex=r'^[0-9\-]+$', 
        error_messages = {'invalid': "Phone number may only contain digits and -."})

    def clean_email(self):
        email = self.cleaned_data["email"]
        print(email)
        try:
            Coach.objects.get(email=email)
        except Coach.DoesNotExist:
            return email
        raise forms.ValidationError("A user with that email already exists.")
        
    class Meta:
        model = Coach
        exclude = ('user', 'has_paid')

class SchoolForm(forms.ModelForm):
    """
    A form that edits a school attached to the current user.
    """
    def __init__(self, user, *args, **kwargs):
        super(SchoolForm, self).__init__(*args, **kwargs)
        self.coach = user

    def clean(self):
        if not self.instance.is_writable(self.coach):
            raise forms.ValidationError("You are not authorized to edit this school at this time.")
        return self.cleaned_data

    class Meta:
        model = School
        exclude = ('coach', 'competition_year',)

class ParticipantForm(forms.ModelForm):
    """
    A form that is part of the TeamForm.
    """
    team_participant_number = forms.IntegerField(widget=forms.HiddenInput, required=False)

    def clean_subject2(self):
        subject1 = self.cleaned_data['subject1']
        subject2 = self.cleaned_data['subject2']
        if subject1 == subject2:
            raise forms.ValidationError("Both tests cannot be the same.")
        return subject2

    class Meta:
        model = Participant
        fields = ('name', 'grade', 'school', 'city', 'state', 'subject1', 'subject2')


# This creates the extra forms for the participants
ParticipantFormSet = modelformset_factory(Participant, can_delete=False, max_num=8, extra=8,
                                           form=ParticipantForm)

class TeamForm(forms.ModelForm):
    """
    A form that edits a team and all of its participants.
    """

    def __init__(self, user, school, data=None, instance=None):
        super(TeamForm, self).__init__(data=data, instance=instance)
        self.user = user
        self.instance.school = school

        queryset = Participant.objects.none()
        if instance:
            # pre-populate participants if the team already exists
            queryset = Participant.objects.filter(team=instance)
        self.formset = ParticipantFormSet(data=data, queryset=queryset)

    def clean(self):
        super(TeamForm, self).clean()
        if not self.instance.is_writable(self.user):
            raise forms.ValidationError("You are not authorized to edit this team at this time.")
        return self.cleaned_data

    def clean_halfteamflag(self):
        """For some reason these aren't displaying.
        """

        halfteamflag = self.cleaned_data['halfteamflag']
        if halfteamflag[0] == 'half team':

            participant_num = len(self.formset)
            if participant_num > 4:
                raise forms.ValidationError("Your half team must have < four participants.")

        return self.cleaned_data['halfteamflag']



    def clean_division(self):
        division = self.cleaned_data['division']
        teamtype = self.cleaned_data['teamtype']
        if teamtype == 'regional' and division == 'B':
            raise forms.ValidationError("Regional teams can only do Division A or Power Round.")
        return division


    def is_valid(self):
        team_valid = super(TeamForm, self).is_valid()
        participants_valid = self.formset.is_valid()

        return team_valid and participants_valid

    def save(self, commit_team=True, commit=True):
        team = super(TeamForm, self).save(commit=False)
        # create database record so we can save participants
        if commit and commit_team:
            team.save()

        participants = self.formset.save(commit=False)
        for participant in participants:
            participant.team = team
            participant.final_score = 0
            participant.weighted_score = 0

            if commit:
                participant.save()

        # save team again, so that participant_count is correct
        if commit and commit_team:
            team.save()

        return team

    class Meta:
        model = Team
        fields = ('name', 'teamtype', 'regional_team_explanation', 'division', 'nationality','halfteamflag',  'team_achievement')

class PassResetForm(forms.Form):
    """
    A form that requests an password recovery.
    """
    email = forms.EmailField()
