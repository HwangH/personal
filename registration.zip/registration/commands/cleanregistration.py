from django.core.management.base import NoArgsCommand, CommandError
from registration.models import Team, School

class Command(NoArgsCommand):
	help = 'Remove non-competing teams and empty schools from the database'

	def handle_noargs(self, **options):
		for team in Team.objects.all():
			if not team.competing:
				team.delete()

		for school in School.objects.all():
			if len(school.team_set.all()) == 0:
				school.delete()
