from django.core.management.base import NoArgsCommand, CommandError
from registration.models import Team, School
import settings
from registration.views import _send_too_many_teams_email, _send_power_rejection_email, _send_power_confirmation_email, _send_waitlist_email, _send_registration_confirmation_email, _send_waiting_on_student_email

class Command(NoArgsCommand):
        help = 'send emails if they havent been sent yet.'

        def handle_noargs(self, **options):
            top_teams = (Team.objects.filter(school__competition_year = settings.REGISTRATION_YEAR-1,
                    division='A', entry='main').order_by('-weighted_score')[:10])
            for team in Team.objects.filter(finalized=True, status='pending', school__competition_year=settings.REGISTRATION_YEAR).order_by('finalized_time'):
                additional_teams = 0
                for top_team in top_teams:
                    if team.school == top_team.school:
                         additional_teams += 1
                if (Team.objects.filter(finalized=True, status='active', school=team.school,
                    school__competition_year=settings.REGISTRATION_YEAR).count() >= 2 + additional_teams):
                    _send_too_many_teams_email(team)

                elif team.entry=='power':
                    if (Team.objects.filter(finalized=True, status='active',
                        school__competition_year=settings.REGISTRATION_YEAR,
                        entry='power').count() >= 20):
                        _send_power_rejection_email(team)
                    else:
                        _send_power_confirmation_email(team)
                elif (team.school.user.coach.country != 'United States' and
                        Team.objects.filter(finalized=True, status='active',
                        school__user__coach__country=team.school.user.coach.country,
                        entry='main', school__competition_year=settings.REGISTRATION_YEAR).count() >=12 ):
                    _send_too_many_teams_email(team)
                elif (Team.objects.filter(finalized=True, status='active',
                        school__competition_year=settings.REGISTRATION_YEAR,
                        entry='main').count() > settings.TEAM_NUM_LIMIT):
                    _send_waitlist_email(team)
                else:
                    if team.participant_count == 8:
                        _send_registration_confirmation_email(team)
                    else:
                        _send_waiting_on_student_email(team)
