from django.conf.urls import *
import views

urlpatterns = [
    url(r'^$', views.index),
    url(r'^register/$', views.register),
    url(r'^profile/$', views.profile, name='profile'),
    url(r'^changepassword/$', views.change_password),
    url(r'^resetpassword/$', views.reset_password),
    url(r'^school/$', views.new_school),
    url(r'^school/copy/(?P<id>\d+)/$', views.new_school),
    url(r'^school/(?P<id>\d+)/$', views.edit_school),
    url(r'^school/(?P<school_id>\d+)/team/$', views.new_team),
    url(r'^school/(?P<school_id>\d+)/team/(?P<id>\d+)/$', views.edit_team),
    url(r'^test_email/$', views.test_send_email),
]
