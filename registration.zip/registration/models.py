from __future__ import unicode_literals
 
from django.db import models
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError
from django.conf import settings

# TODO: why are divisions and entry_types separated?
DIVISIONS = ( ('A', 'A'), ('B', 'B'), ('C', 'Power Round Only') )
TEAMTYPE = ( ('school', 'School Team'), ('regional', 'Regional Team') )
HALFTEAMFLAG = ( ('full team', 'Full team (8 members)'), ('half team', 'Half team (4 Members)'), ('other', 'Other (Explain in Additional Information)') )
NATIONALITY = ( ('domestic', 'Domestic'), ('international', 'International') )
# team admission statuses
STATUSES = (
    ('pending', 'Pending Review'),
    ('accepted', 'Accepted'),
    ('power', 'Power Round'),
    ('waitlisted', 'Waitlisted'),
    ('denied', 'Denied')
)
# test subject choices
TEST_SUBJECTS = (
    ('algebra', 'Algebra'),
    ('combinatorics', 'Combinatorics'),
    ('geometry', 'Geometry'),
    ('number_theory', 'Number Theory'),
)

# Note: 5 represent those in 6
GRADE_CHOICES = (
    (12, 12),
    (11, 11),
    (10, 10),
    (9, 9),
    (8, 8),
    (7, 7),
    (6, 6),
    (5, "< 6"),
)


""" 
The three user types are coaches (registrants bringing teams), 
volunteers (proctors), and admins.
"""

# Extension of the User model for coaches.
class Coach(models.Model):
    user = models.OneToOneField(User, primary_key=True, unique=True)

    name  = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    phone_number = models.CharField(max_length=20)

    street1  = models.CharField(max_length=50, verbose_name="Address")
    street2  = models.CharField(max_length=50, blank=True, verbose_name="")
    city     = models.CharField(max_length=50)
    state    = models.CharField(max_length=50, blank=True)
    zip_code = models.CharField(max_length=10, blank=True)
    country  = models.CharField(max_length=50)

    has_paid = models.BooleanField(default=False)

    class Meta:
        verbose_name_plural = "Coaches"
        ordering = ["name"]

    # coach string should be by name if a name exists, otherwise use the username
    def __unicode__(self):
        if self.user.first_name:
            return "%s %s" % (self.user.first_name, self.user.last_name)
        else:
            return self.user.username

    @staticmethod
    def isCoach(user):
        return hasattr(user, 'coach')

    @staticmethod
    def authorized(user):
        """
        Returns a queryset of objects the user can view and modify.
        """
        if (hasattr(user, 'coach')):
            # check that the user is a coach
            return Coach.objects.filter(user=user)

# Model for competing schools
class School(models.Model):
    competition_year = models.SmallIntegerField(default=settings.REGISTRATION_YEAR,
                                                verbose_name="Competition Year")

    # the user of the coach associated with each school
    coach   = models.ForeignKey(User)

    name    = models.CharField(max_length=100)
    city    = models.CharField(max_length=50)
    # TODO: drop downs for countries?
    state   = models.CharField(max_length=50, blank=True)
    country = models.CharField(max_length=50)

    class Meta:
        verbose_name_plural = "Schools"
        ordering = ['-competition_year', 'name']

    def __unicode__(self):
        return "%s [%d]" % (self.name, self.competition_year)

    @staticmethod
    def authorized(user):
        """
        Returns a queryset of objects the user can view and modify.
        """
        return School.objects.filter(coach=user)

    def is_writable(self, user):
        """
        True if the specified user can modify this object
        The school can be edited when registration is open, there exists a school this year that this user is the coach of,
        and the user is this school's coach.
        """
        if settings.REGISTRATION_LOCKED:
            return False
        if user != self.coach:
            return False
        if self.id:
            if 0 == School.objects.filter(id=self.id, coach=user, competition_year=settings.REGISTRATION_YEAR).count():
                return False
        return True



# Model for competing teams
# TODO: does separating help text out into separate variables make things cleaner? or go back to original?
class Team(models.Model):
    school = models.ForeignKey(School)

    proctor_help_text = "The user chosen must have is_active=True, and the proctor associated with user must have confirmed=True"
    proctor = models.ForeignKey(User, null=True, blank=True, limit_choices_to= models.Q(proctor__confirmed=True) & models.Q(is_active=True))

    name_help_text = 'Team\'s name, not school\'s name'
    name = models.CharField(max_length=100, help_text=name_help_text)

    teamtype_help_text = 'Please indicate whether you\'re a school team or regional team. All members of a school team must be from the same school.'
    teamtype = models.CharField(max_length=20, choices=TEAMTYPE, verbose_name='Team Type', help_text=teamtype_help_text)



    # TODO: aren't division + entry redundant?
    division_help_text = 'If you are a regional team, you cannot select division B'
    division = models.CharField(max_length=1, choices=DIVISIONS, help_text=division_help_text)

    nationality_help_text = 'Please indicate whether you\'re a domestic team or international team'
    nationality = models.CharField(max_length=20, choices=NATIONALITY, verbose_name='Domestic or International', help_text=nationality_help_text)

    # checks whether this team submission has been finalized
    finalized = models.BooleanField(default=False)
    finalized_time = models.DateTimeField(null=True, blank=True)

    # admission status of the team
    # TODO: isn't status and competing also kind of redundant since you can figure out whether they're competing
    # based on the status?
    status = models.CharField(max_length=10, choices=STATUSES, default='pending')

    competing_help_text = """Mark if the team shows up on competition day."""
    competing = models.BooleanField(default=False, help_text=competing_help_text)

    regional_team_explanation_help_text = """
                                          REGIONAL TEAMS ONLY: Please explain in a few sentences why your organization should be allowed to field
                                          a team as a region rather than as separate schools. Keep in mind that regional teams must come from the
                                          same geographic area and must compete in Division A.
                                          """.replace('\n', ' ')
    regional_team_explanation = models.TextField(help_text=regional_team_explanation_help_text, verbose_name="Regional Explanation", null=True, blank=True)

    team_achievement_help_text = """
                                 Please indicate in the following box your school or group\'s performances in competitions, regionally, nationally, 
                                 and internationally, if applicable. Teams are not required to have extensive experience to compete in PUMaC. 
                                 (Examples: PUMaC, HMMT, ARML, etc...). You may also include information about specific individuals on your team,
                                 (Examples: any outstanding individual achievements in math competitions of your team members, or
                                       extenuating circumstances, etc...)
                                 """.replace('\n', ' ')
    team_achievement = models.TextField(help_text=team_achievement_help_text,null=True, blank=True)

    count_help_text = "Make sure to save twice when adding/deleting participants so this and half-team flag is updated!"
    participant_count = models.IntegerField(default=0, help_text=count_help_text)

    # TODO: is is possible to boolean this? what's the point of the 'other'
    halfteamflag_help_text = 'Please indicate whether you\'re a full or half team'
    halfteamflag = models.CharField(max_length=20, choices=HALFTEAMFLAG, verbose_name='Full or Half Team:', help_text=halfteamflag_help_text)



    half_team_with_help_text = "Some of the displayed choices may include teams from other division. The database will automatically reset this if " + \
        " the other team is from the wrong division, but won't let you know. Please double check the divisions/half teams when assigning."


    # NOTE: model referred to by name because Team is
    # n't defined yet
    half_team_with = models.OneToOneField('Team', null=True, blank=True, help_text=half_team_with_help_text,
                                          limit_choices_to=models.Q(halfteamflag="half team") & models.Q(participant_count__lte=4))

    # team results
    team_round_score  = models.IntegerField(null=True, blank=True)
    power_round_score = models.IntegerField(null=True, blank=True)
    individual_total  = models.FloatField(null=True, blank=True, help_text='Automatically calculated')
    weighted_score    = models.FloatField(null=True, blank=True, help_text='Automatically calculated')

    class Meta:
        ordering = ['name']

    def __unicode__(self):
        return self.name

    def get_coach_email(self):
        return self.school.coach.email

    @staticmethod
    def authorized(user):
        """
        Returns a queryset of objects the user can view and modify.
        """
        return Team.objects.filter(school__coach=user)

    def is_writable(self, user):
        """
        True if the user can modify the team
        NOTE: the user is allowed to modify the team even when registration is locked
        """
        if settings.REGISTRATION_LOCKED:
            return True
        else:
            return self.school.is_writable(user)

    def validate_halfteamflag(self):
        self.participant_count = len(Participant.objects.filter(team=self))
        if self.participant_count > 4 and self.halfteamflag == "half team":
            self.halfteamflag = "full team"

    def validate_halfteam(self):
        """
        Make sure that both half teams have the right flags and the right participant count.
        If not, set both to None.
        Return half team with to allow saving after validation.
        """
        self.validate_halfteamflag()
        if self.half_team_with != None:
            other = self.half_team_with
            # check that it's not the same as itself
            if other == self:
                self.half_team_with = None
                return None

            other.validate_halfteamflag()

            if not (self.halfteamflag == "half team" and other.halfteamflag == "half team"):
                other.half_team_with = None
                self.half_team_with = None
            else:

                # If wrong division, don't change the other team
                if self.division != other.division:
                    self.half_team_with = None
                    return other

                other.half_team_with = self
                self.half_team_with = other

            return other
        else:
            return None

    def save(self, *args, **kwargs):
        """
        Make sure that half_team_with is a symmetric relationship on save.
        """

        other_half = self.validate_halfteam()

        super(Team, self).save(*args, **kwargs)

        if other_half != None:
            super(Team, other_half).save(*args, **kwargs)

        # For all teams that point to us incorrectly
        self._save_symmetric()


    def _save_symmetric(self, *args, **kwargs):
        """
        Faster save that assumes half_team_with is already symmetric.
        """

        super(Team, self).save(*args, **kwargs)

        # unset any half teams that point to us incorrectly, usually zero or one team
        half_teams = Team.objects.filter(half_team_with=self)
        for team in half_teams:
            if team != self.half_team_with:
                team.half_team_with = None
                team.save(*args, **kwargs)

# validator functions (ensures that a field is in a certain range and
# raises an appropriate error message if it isn't)2
# these need to be outside of the participant class in order to be serialized
def validate_participant_num(value):
    if value < 1 or value > 8:
        raise ValidationError('Participant is not between 1 and 8')

# Even though this function is no longer used,
def validate_age(value):
    if value < 0 or value > 20:
        raise ValidationError('Age is out of bounds')

# No longer used
def validate_grade(value):
    if value < 5 or value > 12:
        raise ValidationError('Student grade must be between 5 and 12')

# Model for team participants (i.e. competing students)
class Participant(models.Model): 
    team = models.ForeignKey(Team)
    team_participant_number = models.SmallIntegerField(validators=[validate_participant_num])

    name  = models.CharField(max_length=100)
    grade = models.SmallIntegerField(choices=GRADE_CHOICES, blank=True, null=True)

    school_help_text = "The school the participant attends full-time"
    school    = models.CharField(max_length=100, help_text=school_help_text)
    city     = models.CharField(max_length=50)
    state    = models.CharField(max_length=50)

    # the two test subjects this participant has selected
    subject1 = models.CharField(max_length=20, choices=TEST_SUBJECTS, verbose_name="First Subject")
    subject2 = models.CharField(max_length=20, choices=TEST_SUBJECTS, verbose_name="Second Subject")

    # test scores
    weighted_score = models.FloatField(null=True, blank=True, help_text='Automatically calculated')
    final_score    = models.IntegerField(null=True, blank=True, help_text='Enter only for participants in the finals')

    class Meta:
        # ensure there's only one participant with this number per team
        unique_together = ('team', 'team_participant_number')
        ordering = ['team', 'team_participant_number']

    def __unicode__(self):
        return "%s (%s)" % (self.name, self.team.name)

    # find the smallest unused participant number
    def _get_team_participant_number(self):
        others = Participant.objects.filter(team=self.team) # participants already on the team
        numbers = range(1, 9)
        print numbers
        for participant in others:
            numbers.remove(participant.team_participant_number)
        return numbers[0]

    def save(self, *args, **kwargs):
         # assign this user an unused participant number if he doesn't have one
        if not self.team_participant_number:
            self.team_participant_number = self._get_team_participant_number()
        super(Participant, self).save(*args, **kwargs)
