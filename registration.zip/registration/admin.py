from __future__ import unicode_literals

from django.contrib import admin
from django.db.models import Q
from django.contrib.auth.models import User
from django.contrib.auth.admin import UserAdmin

from models import Coach, School, Team, Participant, TEST_SUBJECTS
from admin_actions import *
import registration.invoice

# inlines allow editing of a model from a parent
# max_num specifies the maximum number of inlines allowed
class CoachInline(admin.StackedInline):
        model = Coach
        max_num = 1
class ParticipantInline(admin.StackedInline):
        model = Participant
        extra = 8
        max_num = 8

# registration for all of our models

@admin.register(Coach)
class CoachAdmin(admin.ModelAdmin):
    # gets the username of the user associated with this coach
        def coach_username(coach):
            return coach.user.username
        coach_username.admin_order_field = 'user__username'
        coach_username.short_description = 'Username'

        list_display = ('name', coach_username, 'email', 'country')
        list_filter = ('country',)
        ordering = ('-name',)

@admin.register(School)
class SchoolAdmin(admin.ModelAdmin):
        list_display = ('name', 'country', 'competition_year', 'coach')
        list_filter = ('country', 'competition_year')
        ordering = ('-competition_year', '-name')

@admin.register(Team)
class TeamAdmin(admin.ModelAdmin):
        inlines = [ParticipantInline]

        # get the year this team is competing
        def team_year(team):
                return team.school.competition_year
        team_year.admin_order_field = 'school__competition_year'
        team_year.short_description = 'Year'
        # get the coach for this team
        def team_coach(team):
                return team.school.coach
        team_coach.admin_order_field = 'school__coach'
        team_coach.short_description = 'Coach'

        list_display = (
                'name', 'school', team_year, team_coach, 'division', 'nationality', 'teamtype',
                'regional_team_explanation', 'participant_count', 'halfteamflag', 'half_team_with',
                'finalized', 'competing', 'status', 'proctor', 'power_round_score', 'team_round_score', 
                'individual_total', 'weighted_score',
        )
        list_filter = (
                'school__competition_year', 'competing', 'status', 'nationality','teamtype',
                'division', 'finalized', 'halfteamflag'
        )
        list_editable = ('competing', 'status', 'power_round_score','team_round_score',)
        ordering = ('-school__competition_year', '-name',)

        change_form_template = 'admin_team_change_form.html'
        
        actions = [export_teams, get_tests_per_team, get_invoice]

        # def formfield_for_foreignkey(self, db_field, request=None, **kwargs):
        #         if db_field.name == "proctor":
        #                 kwargs["queryset"] =  User.objects.filter(proctor__confirmed=True, is_active=True)
        #         return super(TeamAdmin, self).formfield_for_foreignkey(db_field, request, **kwargs)
# TODO: not really sure what the functions below are doing so I just kept them as is...
# returns the number of participants doing subject in a team
def subject_count(team, subject):
        filt = Q(subject1=subject) | Q(subject2=subject)
        count = Participant.objects.filter(filt, team=team).count()
        return count

# returns the subject tests in the packet a team needs
def packet(team):
        result = ""
        for subject in TEST_SUBJECTS:
                result += "%s: %s " % (subject[1], subject_count(team, subject[0]))
        return result

# returns the packet if possible
def try_packet(team_id):
        team = Team.objects.get(id=team_id)
        if team == None:
                return None
        return packet(team)

def change_view(self, request, object_id, extra_context=None):
        team = Team.objects.get(pk=object_id)
        if team != None:
                context = { 'before_inlines': [ packet(team) ] }
        else:
                context = None
        return super(TeamAdmin, self).change_view(request, object_id, extra_context=context)


# Todo: This seems to do something for the proctor, deprecated since ends in "@"
def formfield_for_foreignkey(self, db_field, request, **kwargs):
        if db_field.name == "proctor":
                kwargs["queryset"] = User.objects.filter(username__endswith='@')
        return super(TeamAdmin, self).formfield_for_foreignkey(db_field, request, **kwargs)

def queryset(self, request):
        """Bring in proctors efficiently"""
        return super(TeamAdmin, self).queryset(request).select_related('school', 'school__user', 'proctor')

@admin.register(Participant)
class ParticipantAdmin(admin.ModelAdmin):
        # get the year this participant is competing
        def participant_year(participant):
                return participant.team.school.competition_year
        participant_year.admin_order_field = 'participant__team__school__competition_year'
        participant_year.short_description = 'Year'

        # get the division (A, B, or power round only) this participant is competing in
        def participant_division(participant):
                return participant.team.division
        participant_division.admin_order_field = 'team__division'
        participant_year.short_description     = 'Division'

        list_display = (
                'name','team', participant_year, 'grade', participant_division, 
                'subject1', 'subject2', 'final_score', 'weighted_score'
        )
        list_filter = ('team__school__competition_year', 'team__division')
        search_fields = ('name',)
        
        actions = [export_csv_top10individual, export_participants]

# register the custom user interface
class CustomUserAdmin(UserAdmin):
    fieldsets = (
        UserAdmin.fieldsets[0], # username / password
        ('Admin status', {'fields': ('is_active', 'is_staff', 'is_superuser')}),
        ('Personal info (not used)', {'fields': ('first_name', 'last_name', 'email')}),
    )
    inlines = [CoachInline]
    list_display = ('username', 'is_staff', 'is_superuser',)
admin.site.unregister(User)
admin.site.register(User, CustomUserAdmin)
