from __future__ import unicode_literals

from django.contrib import admin
from grading.models import Proctor, Test

@admin.register(Proctor)
class ProctorAdmin(admin.ModelAdmin):
    # gets the username of the user associated with this proctor
    def proctor_username(proctor):
        return proctor.user.username
    proctor_username.admin_order_field = 'proctor_username'
    proctor_username.short_description = 'Username'

    list_display = (proctor_username, 'name', 'email', 'confirmed')
    ordering = ('-name',)

# Errr, rewrite. this is now broken b/c results.answers() changed
# def correct(result):
    # s = ""
    # for _,_,_,is_correct in result.answers():
        # s += "1" if is_correct else "0"
    # return s

def team(result):
    return result.participant.team
team.admin_order_field = 'participant__team__id'

def year(result):
    return result.participant.team.school.competition_year
year.admin_order_field = 'participant__team__school__competition_year'


def export_csv(modeladmin, request, queryset):
    response = HttpResponse(mimetype='text/csv')
    response['Content-Disposition'] = 'attachment; filename=allResults.csv'
    writer = csv.writer(response, csv.excel)
    response.write(u'\ufeff'.encode('utf8')) 
    writer.writerow([
        smart_str(u"Participant"),
        smart_str(u"Test"),
        smart_str(u"Score"),
    ])
    for obj in queryset:
        writer.writerow([
            smart_str(obj.participant.name),
            smart_str(obj.test),
            smart_str(obj.score),
        ])
    return response
export_csv.short_description = u"Export CSV"

def export_csv_top10forAlgebra(modeladmin, request, queryset):
    response = HttpResponse(mimetype='text/csv')
    response['Content-Disposition'] = 'attachment; filename=top10 for Albegra.csv'
    writer = csv.writer(response, csv.excel)
    response.write(u'\ufeff'.encode('utf8')) 
    top10 = sorted(queryset, key=lambda x: x.score, reverse = True)[:10]
    for x in range (1, 10):
        writer.writerow([smart_str(u"ALGEBRA0"+str(x)), smart_str(top10[x-1].participant.name), smart_str(top10[x-1].score)])
    writer.writerow([smart_str(u"ALGEBRA10"), smart_str(top10[x-1].participant.name), smart_str(top10[x-1].score)]) 
    return response
export_csv_top10forAlgebra.short_description = u"Export CSV of top 10 for Algebra"

def export_csv_top10forCombinatorics(modeladmin, request, queryset):
    response = HttpResponse(mimetype='text/csv')
    response['Content-Disposition'] = 'attachment; filename=top10 for Combinatorics.csv'
    writer = csv.writer(response, csv.excel)
    response.write(u'\ufeff'.encode('utf8')) 
    top10 = sorted(queryset, key=lambda x: x.score, reverse = True)[:10]
    for x in range (1, 10):
        writer.writerow([smart_str(u"COMBINATORICS0"+str(x)), smart_str(top10[x-1].participant.name), smart_str(top10[x-1].score)])
    writer.writerow([smart_str(u"COMBINATORICS10"), smart_str(top10[x-1].participant.name), smart_str(top10[x-1].score)]) 
    return response
export_csv_top10forCombinatorics.short_description = u"Export CSV of top 10 for Combinatorics"

def export_csv_top10forGeometry(modeladmin, request, queryset):
    response = HttpResponse(mimetype='text/csv')
    response['Content-Disposition'] = 'attachment; filename=top10 for Geometry.csv'
    writer = csv.writer(response, csv.excel)
    response.write(u'\ufeff'.encode('utf8')) 
    top10 = sorted(queryset, key=lambda x: x.score, reverse = True)[:10]
    for x in range (1, 10):
        writer.writerow([smart_str(u"GEOMETRY0"+str(x)), smart_str(top10[x-1].participant.name), smart_str(top10[x-1].score)])
    writer.writerow([smart_str(u"GEOMETRY10"), smart_str(top10[x-1].participant.name), smart_str(top10[x-1].score)]) 
    return response
export_csv_top10forGeometry.short_description = u"Export CSV of top 10 for Geometry"

def export_csv_top10forNumberTheory(modeladmin, request, queryset):
    response = HttpResponse(mimetype='text/csv')
    response['Content-Disposition'] = 'attachment; filename=top10 for Number Theory.csv'
    writer = csv.writer(response, csv.excel)
    response.write(u'\ufeff'.encode('utf8')) 
    top10 = sorted(queryset, key=lambda x: x.score, reverse = True)[:10]
    for x in range (1, 10):
        writer.writerow([smart_str(u"NUMBERTHEORY0"+str(x)), smart_str(top10[x-1].participant.name), smart_str(top10[x-1].score)])
    writer.writerow([smart_str(u"NUMBERTHEORY10"), smart_str(top10[x-1].participant.name), smart_str(top10[x-1].score)]) 
    return response
export_csv_top10forNumberTheory.short_description = u"Export CSV of top 10 for Number Theory"

# class ResultAdmin(admin.ModelAdmin): TODO: migrate Result over.
    # model = Result
    # list_display = ('participant', team, year, correct, 'test', 'score')
    # list_filter = ('test__competition_year', 'test__division', 'test__subject', 'score')
    # search_fields = ('participant__name', 'participant__team__name')
    # actions = [export_csv_top10forAlgebra, export_csv_top10forCombinatorics, export_csv_top10forGeometry, export_csv_top10forNumberTheory]

class TestAdmin(admin.ModelAdmin):
    model = Test
    list_filter = ('competition_year', 'division')

admin.site.register(Test, TestAdmin)
# admin.site.register(Result, ResultAdmin) TODO: migrate Result over
