from __future__ import unicode_literals
 
from django.db import models
from django.contrib.auth.models import User
from django.conf import settings
from registration.models import Participant, Team
from registration.models import DIVISIONS, TEST_SUBJECTS

# Extension of the User model for proctors.
class Proctor(models.Model):
    user = models.OneToOneField(User, primary_key=True, unique=True)

    name  = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    phone_number = models.CharField(max_length=20)

    # whether or not this user has been confirmed to be a proctor
    confirmed = models.BooleanField(default=False)

    class Meta:
        verbose_name_plural = "Proctors"
        ordering = ["confirmed", "name"]

    def __unicode__(self):
        return self.user.username

    @staticmethod
    def isProctor(user):
        return hasattr(user, 'proctor')

    @staticmethod
    def isConfirmedProctor(user):
        return (hasattr(user, 'proctor') and user.proctor.confirmed)

    @staticmethod
    def authorized(user):
        """
        Returns a queryset of objects the user can view and modify.
        """
        if (hasattr(user, 'proctor')): # check that the user is a proctor
            return Proctor.objects.filter(user=user)


class Test(models.Model):
    subject = models.CharField(max_length=20, choices=TEST_SUBJECTS)
    division = models.CharField(max_length=1, choices=DIVISIONS)
    competition_year = models.SmallIntegerField(verbose_name="Year")
    
    #raw scores that are not normalized. key: participant. value: raw score
    raw_scores = {}
    
    # 8 for indivs. 
    answer_count = models.IntegerField()
    
    # HARD CODING FOR DAYYYYYYYYYYYYYYS
    correctAnswers = [models.CharField(max_length=100, null=True, blank=True) for i in range(8)]
    values = [models.DecimalField(max_length=100, null=True, blank=True) for i in range(8)]

    # answer_1 = models.CharField(max_length=100, null=True, blank=True)
    # answer_2 = models.CharField(max_length=100, null=True, blank=True)
    # answer_3 = models.CharField(max_length=100, null=True, blank=True)
    # answer_3 = models.CharField(max_length=100, null=True, blank=True)
    # answer_4 = models.CharField(max_length=100, null=True, blank=True)
    # answer_5 = models.CharField(max_length=100, null=True, blank=True)
    # answer_6 = models.CharField(max_length=100, null=True, blank=True)
    # answer_7 = models.CharField(max_length=100, null=True, blank=True)
    # answer_8 = models.CharField(max_length=100, null=True, blank=True)
    # answer_9 = models.CharField(max_length=100, null=True, blank=True)
    # answer_10 = models.CharField(max_length=100, null=True, blank=True)

    # value_1 = models.DecimalField(null=True, blank=True)
    # value_2 = models.IntegerField(null=True, blank=True)
    # value_3 = models.IntegerField(null=True, blank=True)
    # value_4 = models.IntegerField(null=True, blank=True)
    # value_5 = models.IntegerField(null=True, blank=True)
    # value_6 = models.IntegerField(null=True, blank=True)
    # value_7 = models.IntegerField(null=True, blank=True)
    # value_8 = models.IntegerField(null=True, blank=True)
    # value_9 = models.IntegerField(null=True, blank=True)
    # value_10 = models.IntegerField(null=True, blank=True)

    class Meta:
        unique_together = ('subject', 'division', 'competition_year')

    def __unicode__(self):
        return self.get_subject_display() + " " + self.get_division_display() + ' [' + str(self.competition_year) + ']'
        
def is_correct(response, answer_key):
    """
    True if student's response corresponds to one of the answers in the comma separated
    list of integers in answer_key.
    """
    if response == None or answer_key == None:
        return False
    # Splits answer_key into an int list, then checks if the student response is
    # in that list
    return int(response) in [int(choice) for choice in answer_key.split(',')]

class Result(models.Model):
    participant = models.ForeignKey(Participant)
    test = models.ForeignKey(Test)
    
    # HARD CODING 8 
    answers = [models.IntegerField(null=True, blank=True) for i in range(8)]

    # answer_1 = models.IntegerField(null=True, blank=True)
    # answer_2 = models.IntegerField(null=True, blank=True)
    # answer_3 = models.IntegerField(null=True, blank=True)
    # answer_4 = models.IntegerField(null=True, blank=True)
    # answer_5 = models.IntegerField(null=True, blank=True)
    # answer_6 = models.IntegerField(null=True, blank=True)
    # answer_7 = models.IntegerField(null=True, blank=True)
    # answer_8 = models.IntegerField(null=True, blank=True)
    # answer_9 = models.IntegerField(null=True, blank=True)
    # answer_10 = models.IntegerField(null=True, blank=True)

    raw_score = models.DecimalField(max_digits = 15, decimal_places = 10)

    normalized_score = {} #dictionary. key = normalized ideal. value = normalized score
    
    class Meta:
        unique_together = ('test', 'participant')

    # def save(self, *args, **kwargs):
        # self.score = 0
        # for _, _, value, correct in self.answers():
            # if correct:
                # self.score += value
        # super(Result, self).save(*args, **kwargs)

    def save(self, *args, **kwargs):
        # a check to make sure the values of questions has been computed already.
        if isinstance(test.values[0], float):
            self.raw_score = 0
            for iter, bool in self.grade():
                if bool:
                    self.raw_score+=self.test.values[iter]
        super(Result, self).save(*args,**kwargs)
            
        
    # def answers(self):
        # """
        # Yields (response, answer_key, value, correctness) tuples for each answer.
        # """
        # for i in range(1, self.test.answer_count + 1):
            # response = getattr(self, 'answer_{0}'.format(i))
            # answer_key = getattr(self.test, 'answer_{0}'.format(i))
            # value = getattr(self.test, 'value_{0}'.format(i))
            # yield response, answer_key, value, is_correct(response, answer_key)
        
    def grade(self):
        for i in range(self.test.answer_count):
            yield i, self.answers[i] == self.test.correctAnswers[i]
            
        
        
