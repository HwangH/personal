from django.conf.urls import *

import grading.views as views


urlpatterns = [
    url(r'^$', views.index),
    url(r'^register/$', views.register, name='proctor_register'),
    url(r'^profile/$', views.profile, name='proctor_profile'),
    url(r'^changepassword/$', views.change_password, name='proctor_changepassword'),
    url(r'^resetpassword/$', views.reset_password, name='proctor_resetpassword'),
    url(r'^choose_team/$', views.choose_team),
    url(r'^submitgrades/(?P<id>\d+)/$', views.team_grade),
    url(r'^recalculate/$', views.recalculate_scores),
    url(r'^indv_final/(?P<division>\d{1})/$', views.indv_final),
    url(r'^top_indv/(?P<division>\d{1})/$', views.top_indv),
    url(r'^top_team/(?P<division>\d{1})$', views.top_team),
    url(r'^top_test/(?P<test_id>\d+)$', views.top_test),
]
