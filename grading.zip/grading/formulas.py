import numpy, math
from django.db.models.signals import pre_save
from grading.models import Result, Test
from registration.models import Team, Participant
from pumac2.settings import REGISTRATION_YEAR

###############################################################################

dictionaryOfTestsAndIdealNorm = {} 
## use to calculate the weighted scores for different exponents
## key: (test,ideal_norm). value: list of results for that test with that ideal_norm

dictionaryOfTeamSums = {} 
## used for the weighted individual components for team score
## key: (TEAM/POWER/INDIVSUM, norm_ideal). value: dictionary of (key: team, value: score)
## key of -1 is used for raw scores.

FINAL = 'finalvar' ## used as keys in certain dictionaries.
TEAM = 'teamvar'
POWER = 'powervar'
INDIVSUM = 'indivaggvar'

expTopTen = {}

## the raw scores for individual finals
finalsRaw = {}

###############################################################################

def update_scores(): 
    for test in Test.objects.filter(competition_year = REGISTRATION_YEAR):
        _compute_weights_and_raw_scores(test)
        
    # compute the 0.3 + .7 ideal normalized scores used for final team score. 
    # it is done for all tests. 0.7 is for indiv aggregate and 0.3 for team agg
    # this is stored in Result.normalized_score dictionary.
    for test in Test.objects.filter(competition_year = REGISTRATION_YEAR):
        _compute_normalized_scores(test, 0.3)
        _compute_normalized_scores_with_exponent(test, _find_exp_from_top_ten(test))
        ### NOTE THIS IS HARDCODED w/ 0.3 and 0.5 inside _find_exp_from_top_ten

    # 
    update_participants()
    
    update_teams()
        

# for the given input test_id, constructs the weights of the questions and raw scores 
# for all results with that test_id. saves dictionary of raw scores
def _compute_weights_and_raw_scores(aTest):                             
    tests = Result.objects.filter(test=aTest)
    if len(tests) == 0:
        raise Exception('no such test')
    numQuestions = aTest.answer_count
    weights = [0 for i in range(numQuestions)]
    numCorrect = [0 for i in range(numQuestions)]
    numTakers = len(tests)
    for i in range(numQuestions):
        for test in tests:
            if (test.answers[i] == aTest.correctAnswers[i]):
                numCorrect[i]+=1
    for i in range(numQuestions):
        if numCorrect[i] != 0:
            weights[i] = 1+math.log(numTakers/numCorrect,math.e)
    aTest.values = weights
    
    aTest.save()
    
    for test in tests:
        test.save()

    aTest.raw_scores = {}
    
    for i in Results.objects.filter(test = aTest):
        aTest.raw_scores[i.participant] = i.raw_score
    
    aTest.save()    
    
    return

# returns a new normalized dict of scores. scores and return type are both dictionary with 
# value: particpant/team/anything (the values are kept in return type). key: score.
def _normalize_list(scores, normalizedScore):
    scoresHRS = {}
    strippedscores = []
    for i in scores:
        strippedscores.append(scores[i])
    
    power = _find_power(strippedscores, normalizedScore)
    HRS = _find_HRS(strippedscores)
    for i in scores:
        scoresHRS[i] = (scores[i]/HRS)**power
        
    return scoresHRS
    
# returns a new normalized dict of scores. scores and return type are both dictionary with 
# value: particpant. key: score.    THIS is when the wanted exponent is given.
def _normalize_list_with_exponent(scores, normalizedScore, exp):
    scoresHRS = {}
    strippedscores = []
    for i in scores:
        strippedscores.append(scores[i])
    
    
    HRS = _find_HRS(strippedscores)
    for i in scores:
        scoresHRS[i] = (scores[i]/HRS)**exp
        
    return scoresHRS
 
# returns power. scores is a list of pure numbers
def _find_power(scores, normalizedScore):
    scoresHRS = []
    HRS = _find_HRS(scores)
    for i in scores:
        scoresHRS.append(i/HRS)
    power = 1
    scoresHRS=numpy.array(scoresHRS)
    diff = 0.01
    iter = 0.5
    while (abs(numpy.mean(scoresHRS**power)-normalizedScore)>diff):
        if numpy.mean(scoresHRS**power) > normalizedScore:
            power -= iter 
            iter /=2
        else:
            power += iter 
            iter /=2
    
    return power
 
# returns HRS. scores is a list of pure numbers
def _find_HRS(scores):
    scores.sort()
    iter = 1
    HRS = 0
    for i in scores[::-1]:
        HRS+=iter*i
        iter/=2
    return HRS     

# computes the desired esoteric exp for a test to use to normalize.
def _find_exp_from_top_ten(test):
    strippedscores = []
    for x in test.raw_scores:
        strippedscores.append(test.raw_scores[x])
    
    strippedscores.sort()
    topten = list(strippedscores[len(strippedscores):len(strippedscores)-11:-1])
    expTopTen[test] = _find_power(topten, 0.7)
    return expTopTen[test] #MAGIC NUMBER
     
# for the given test, constructs Result.normalized_score[ideal_norm]
# make sure the raw score has been computed already. + aTest.raw_scores has been made
def _compute_normalized_scores(aTest, ideal_norm):
    # dictionaryOfTests[aTest] = aTest.raw_scores
    dictionaryOfTestsAndIdealNorm[(aTest, ideal_norm)] = _normalize_list(aTest.raw_scores, ideal_norm)
    
    # then store these in the Result.normalized_score
    for result in Results.objects.filter(test = aTest):
        result.normalized_score[ideal_norm] = dictionaryOfTestsAndIdealNorm[(aTest,ideal_norm)][result.participant]

# used in update_participants to compute final score of individiuals
def _compute_normalized_scores_finals(ideal_norm):
    finalsRaw = {}
    for aTeam in Team.objects.filter(competition_year = REGISTRATION_YEAR, competing = True):
        for participant in Participant.objects.filter(team = aTeam):
            finalsRaw[participant] = participant.final_score
            
    dictionaryOfTestsAndIdealNorm[(FINAL, ideal_norm)] = _normalize_list(finalsRaw, ideal_norm)
    return

# updates the participants. called in update_scores. Use to find finals participants 
# and compute their final scores afterwards.
def update_participants():
    for aTest in Test.objects.filter(competition_year = REGISTRATION_YEAR):
        for results in Result.objects.filter(test = aTest):
            results.participant.weighted_score = 0 # resets everything to recalculate
        
    for aTest in Test.objects.filter(competition_year = REGISTRATION_YEAR):
        for results in Result.objects.filter(test = aTest):
            results.participant.weighted_score += result.normalized_score[expTopTen[aTest]]
            
    _compute_normalized_scores_finals(0.7)
    scores = dictionaryOfTestsAndIdealNorm[(FINAL, 0.7)]
    for participant in scores:
        participant.weighted_score += 2 * scores[participant]
    
    return
    
# updates the team with their finals scores
def update_teams():
    ### constructs the Team.individual_total
    for aTeam in Team.objects.filter(competition_year = REGISTRATION_YEAR, competing = True):
        aTeam.individual_total = 0
        for aTest in Test.objects.filter(competition_year = REGISTRATION_YEAR):
            listResults = Result.objects.filter(participant__team = aTeam, test = aTest)
            listScores = []
            for r in listResults:
                listScore.append(r.normalized_score[0.3])
            listScore.sort()
            topFive = listScore[len(listScore):len(listScore)-6:-1]
            aTeam.individual_total += sum(topFive)
    
    ### creates the normalization of all the team components with magic number ideal_norm of 0.5 
    dictsum = {}
    dictteam = {}
    dictpower = {}
    for aTeam in Team.objects.filter(competition_year = REGISTRATION_YEAR, competing = True):
        dictsum[aTeam] = aTeam.individual_total
        dictteam[aTeam] = aTeam.team_round_score
        dictpower[aTeam] = aTeam.power_round_score
        
    dictionaryOfTeamSums[(INDIVSUM, -1)] = dictsum
    dictionaryOfTeamSums[(TEAM, -1)] = dictteam
    dictionaryOfTeamSums[(POWER, -1)] = dictpower
    
    
    dictionaryOfTeamSums[(INDIVSUM, 0.5)] = _normalize_list(dictionaryOfTeamSums[(INDIVSUM, -1)], 0.5)
    dictionaryOfTeamSums[(TEAM, 0.5)] = _normalize_list(dictionaryOfTeamSums[(TEAM, -1)], 0.5)
    dictionaryOfTeamSums[(POWER, 0.5)] = _normalize_list(dictionaryOfTeamSums[(POWER, -1)], 0.5)
    
    ### Sums everything
    for aTeam in Team.objects.filter(competition_year = REGISTRATION_YEAR, competing = True):
        aTeam.weighted_score = 2*dictionaryOfTeamSums[INDIVSUM, 0.5][aTeam]
        aTeam.weighted_score += 2*dictionaryOfTeamSums[(POWER, 0.5)][aTeam] + dictionaryOfTeamSums[(TEAM, 0.5)][aTeam]
        
    return
   
### pre_save.connect(update_scores, sender=Team) iono if this should be used. this might slow performance?