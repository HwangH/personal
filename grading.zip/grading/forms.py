from django import forms
from django.conf import settings
from django.forms.formsets import formset_factory
from django.forms.models import model_to_dict, modelformset_factory
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError

from registration.models import Coach, School, Team, Participant, TEST_SUBJECTS
from grading.models import Proctor, Result

class UserCreationForm(forms.ModelForm):
    """
    django.contrib.auth.forms.UserCreationForm with a different username regex.
    """
    username = forms.RegexField(label="Username", max_length=30, regex=r'^[\w.\-_]+$',
        help_text = "Required. 30 characters or fewer. Letters, digits and . - _ only.",
        error_messages = {'invalid': "Username may contain only letters, numbers and . - _ characters."})
    password1 = forms.CharField(label="Password", widget=forms.PasswordInput)
    password2 = forms.CharField(label="Password confirmation", widget=forms.PasswordInput,
        help_text = "Enter the same password as above, for verification.")

    class Meta:
        model = User
        fields = ('username',)

    def clean_username(self):
        username = self.cleaned_data["username"]
        try:
            User.objects.get(username=username)
        except User.DoesNotExist:
            return username
        raise forms.ValidationError("A user with that username already exists.")

    def clean_password2(self):
        MIN_PASS_LENGTH = 8

        password1 = self.cleaned_data.get("password1", "")
        if len(password1) < MIN_PASS_LENGTH:
            raise ValidationError("Password must be at least %d characters." % (MIN_PASS_LENGTH))
        password2 = self.cleaned_data["password2"]

        if password1 != password2:
            raise forms.ValidationError("The two password fields didn't match.")
        return password2

    def save(self, commit=True):
        user = super(UserCreationForm, self).save(commit=False)
        user.set_password(self.cleaned_data["password1"])
        user.save()

        # create a proctor object associated with this user
        try:
            proctor = Proctor.authorized(user).get()
        except:
            proctor = Proctor.objects.create(user=user)

        return user

class ProctorForm(forms.ModelForm):
    """
    A form for a proctor's profile
    """
    phone_number = forms.RegexField(label="Phone Number", regex=r'^[0-9\-]+$', error_messages = {'invalid': "Phone number may only contain digits and -."})

    def clean_email(self):
        email = self.cleaned_data["email"]
        print(email)
        try:
            Proctor.objects.get(email=email)
        except Proctor.DoesNotExist:
            return email
        raise forms.ValidationError("A user with that email already exists.")

    class Meta:
        model = Proctor
        exclude = ('user', 'confirmed')

class PassResetForm(forms.Form):
    """
    A form that requests an password recovery.
    """
    email = forms.EmailField()

class GradingForm(forms.ModelForm):
    participant = forms.ModelChoiceField(queryset=Participant.objects.none())
    test = forms.ChoiceField(choices=TEST_SUBJECTS)

    class Meta:
        model = Result
        exclude = ('raw_score', 'normalized_score',)

    def __init__(self, team, data=None):
        super(GradingForm, self).__init__(data=data)
        self.fields['participant'].queryset = Participant.objects.filter(team=team)
        self.team = team

    def clean_test(self):
        test = self.cleaned_data['test']
        try:
            testobj = Test.objects.get(subject=test, division=self.team.division, competition_year=settings.REGISTRATION_YEAR)
        except Test.DoesNotExist:
            raise forms.ValidationError('Could not find specified test.')
        return testobj

    def clean_participant(self):
        participant = self.cleaned_data['participant']
        count = Result.objects.filter(participant=participant).count()
        if count > 2:
            raise forms.ValidationError('You have already submitted two tests for this participant. Contact the command center if you think this message is in error.')
        return participant

    def save(self):
        result = super(GradingForm, self).save(commit=False)
        result.save()
        return result
