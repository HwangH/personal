from datetime import datetime
from random import sample
from django.http import HttpResponseForbidden
from django.shortcuts import render_to_response
from django.template import RequestContext, Template, Context, loader
from django.http import HttpResponse, HttpResponseRedirect
from django.core.urlresolvers import reverse
from django.core.mail import EmailMessage, send_mail
from django.conf import settings
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import PasswordChangeForm
from django.contrib.auth.views import login

from registration.models import Team
from grading.models import Proctor
from grading.forms import UserCreationForm, ProctorForm, PassResetForm
from grading.formulas import *

PROCTOR_LOGIN = '/proctors/login'

def _nav(user):
    if not user.is_authenticated():
        # don't call this function with an anonymous user
        return

    # what teams is this proctor proctoring for?
    proctoring = Team.objects.filter(proctor=user, school__competition_year=settings.REGISTRATION_YEAR)

    nav = {}
    if proctoring.count() > 0:
        # user is proctor for some teams
        nav['proctor_auth'] = True
        nav['teams'] = proctoring

    return nav

# check that a user is a confirmed proctor, if not return an error message
def is_proctor(user):
    return Proctor.isProctor(user)
def is_confirmedProctor(user):
    return Proctor.isConfirmedProctor(user)
def proctor_error():
    error = '<h1>Forbidden</h1><p>You do not have staff privileges.</p>'
    return HttpResponseForbidden(error)    

def proctor_login(request, **kwargs):
    if request.user.is_authenticated() and is_proctor(request.user):
        return HttpResponseRedirect(reverse(profile))
    else:
        return login(request, **kwargs)



@login_required(login_url=PROCTOR_LOGIN)
def index(request):
    if not is_proctor(request.user):
        return proctor_error
    return HttpResponseRedirect(reverse(profile))

def register(request):
    if request.method == "POST":
        user_form = UserCreationForm(request.POST)
        proctor_form = ProctorForm(request.POST)
        # print "post proctors"

        if user_form.is_valid() and proctor_form.is_valid():
            user = user_form.save()
            proctor = proctor_form.save(commit=False)
            proctor.user = user
            proctor.save()
            messages.success(request, 'Thank you for registering. We will confirm your position as proctor as soon as possible.')
            return HttpResponseRedirect(reverse(profile))
        messages.error(request, 'There were errors. Please try again.')
    else:
        user_form = UserCreationForm()
        proctor_form = ProctorForm()


    return render_to_response('user_proctor_form.html', {
        'user_form': user_form,
        'proctor_form': proctor_form,
        'formtitle': 'Proctor Registration Form'
    }, context_instance=RequestContext(request))

def _add_proctor_message(request):
    if Proctor.authorized(request.user).count() == 0:
        msg = 'You will need to fill out your profile before you can proctor.'
    elif not Proctor.isConfirmedProctor(request.user):
        msg = 'You have not yet been confirmed by the PuMAC staff as a proctor.'
    else:
        msg = 'You have been confirmed as a proctor!'
    messages.info(request, msg)

@login_required(login_url=PROCTOR_LOGIN)
def profile(request):
    if not is_proctor(request.user):
        return proctor_error()

    if request.method == "POST":
        proctor = Proctor.authorized(request.user).get()
        form = ProctorForm(request.POST, instance=proctor)
        if form.is_valid():
            # we can assume that the profile is attached to our user
            form.save()
            messages.success(request, 'Profile updated successfully.')
            return HttpResponseRedirect(reverse(profile))
    else:
        proctor = Proctor.authorized(request.user).get()
        form = ProctorForm(instance=proctor)
        _add_proctor_message(request)

    return render_to_response('proctor_form.html', {
        'nav': _nav(request.user),
        'formtitle': 'Profile',
        'form': form,
    }, context_instance=RequestContext(request))

@login_required(login_url=PROCTOR_LOGIN)
def change_password(request):
    if not is_proctor(request.user):
        return proctor_error()

    if request.method == "POST":
        form = PasswordChangeForm(request.user, request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Password changed.')
            return HttpResponseRedirect(reverse(profile))
    else:
        form = PasswordChangeForm(request.user)

    return render_to_response('proctor_form.html', {
        'nav': _nav(request.user),
        'formtitle': 'Change Password',
        'form': form,
    }, context_instance=RequestContext(request))


def _send_reset_email(to_address, username, reset_code):
    msg = """Your password at https://pumac.princeton.edu/proctors/ has been reset. If you did not request this, and this email is unexpected, please let us know.

Here is your new login information: \nUsername: {0}\nPassword: {1}

We recommend changing this password. You can do so at https://pumac.princeton.edu/proctors/changepassword/

If you have any questions or concerns, feel free to email us by replying to this email.""".format(username, reset_code)
    send_mail('PUMaC Password Reset', msg, settings.EMAIL_HOST_USER, [to_address], fail_silently=False)

def reset_password(request):
    if request.method == "POST":
        form = PassResetForm(request.POST)
        if form.is_valid():
            try:
                email = form.cleaned_data['email']
                proctor = Proctor.objects.get(email=email)
                new_pass = ''.join(sample("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789", 10))
                try:
                    _send_reset_email(email, proctor.user.username, new_pass)
                    proctor.user.set_password(new_pass)
                    proctor.user.save()
                    messages.success(request, "Your password was reset. You should receive an email " + 
                                              "with your new password. Let us know at " + 
                                              "pumac.staff@gmail.com if there are any problems.")
                except Exception as e:
                    messages.error(request, "There was an error sending your password reset email, please let us know at pumac.staff@gmail.com")
            except Proctor.DoesNotExist: # cannot find a corresponding proctor
                messages.error(request, "We couldn't find a proctor account with that email address. Please try again.")

    else:
        form = PassResetForm()

    return render_to_response('proctor_form.html', {
        'form': form,
        'formtitle': 'Reset your password',
    }, context_instance=RequestContext(request))

#Above is to do proctor login work. Below is actual functions of a proctor.

@login_required(login_url=PROCTOR_LOGIN)
def choose_team(request):
    if not is_proctor(request.user):
        return proctor_error()


    teams = Team.objects.filter(school__competition_year=settings.REGISTRATION_YEAR, competing=True)
    if request.method == "POST":
        try:
            team = teams.get(name=request.POST.get('team_proctor'))
        except Team.DoesNotExist:
            messages.error('Team not found.')
            return HttpResponseRedirect(reverse(choose_team))

        if team.proctor:
            messages.error('There is already a proctor assigned to that team. If you need this changed, contact Command Center.')
            return HttpResponseRedirect(reverse(choose_team))

        team.proctor = request.user
        team.save()
        messages.success(request, 'Team assigned successfully')
        return HttpResponseRedirect(reverse(index))#, kwargs={'id': team.id}))

    return render_to_response('choose_team_form.html', {
        'nav': _nav(request.user),
        'teams': teams}, context_instance=RequestContext(request))

## unsure how it works...
def team_grade(request, id):
    if not request.user.is_authenticated():
        return HttpResponseRedirect(reverse('proctor_login'))

    if not is_proctor(request.user):
        return proctor_error()


    try:
        team = Team.objects.filter(proctor=request.user, school__competition_year=settings.REGISTRATION_YEAR).get(id=id)
    except Team.DoesNotExist:
        return HttpResponseRedirect(reverse(index))

    if request.method == "POST":
        form = GradingForm(team, request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Successfully submitted %s answers for %s.' % (e(form.cleaned_data['test']), e(form.cleaned_data['participant'])))
            return HttpResponseRedirect(reverse(team_grade, kwargs={'id': id}))
        messages.error(request, 'There were errors. Please see below.')
    else:
        form = GradingForm(team)

    return render_to_response('grading_form.html', {
        'nav': _nav(request.user),
        'form': form,
        'formtitle': 'Submitting answers for team ' + team.name,
    }, context_instance=RequestContext(request))

## runs everything
def recalculate_scores(request):
    if not request.user.is_staff:
        return HttpResponseRedirect(reverse(index))

    if not is_proctor(request.user):
        return proctor_error()

    update_scores()

    return HttpResponseRedirect(reverse(index))

class Data(object):
    def __init__(self, title, columns):
        self.title = title
        self.columns = columns
        self.rows = []

    def add_row(self, row):
        self.rows.append(row)


def progress(request):
    if not request.user.is_staff:
        return HttpResponseRedirect(reverse(index))

    if is_coach(request.user):
        return is_coach_error()

    data = Data('Submission progress', ['Team', 'Proctor', 'Progress'])
    for team in Team.objects.filter(competing=True, entry='main', school__competition_year=settings.REGISTRATION_YEAR):
        partcount = Participant.objects.filter(team=team).count()
        resultcount = Result.objects.filter(participant__team=team).count()
        data.add_row([str(team), str(team.proctor), "%s / %s" % (resultcount, partcount * 2)])

    return render_to_response('grading_data.html', {
        'nav': _nav(request.user),
        'data': [data],
    }, context_instance=RequestContext(request))


def standings(request):
    if not request.user.is_staff:
        return HttpResponseRedirect(reverse('proctor_login'))

    if is_coach(request.user):
        return is_coach_error()

    test_list = Test.objects.filter(competition_year = settings.REGISTRATION_YEAR)

    return render_to_response('standings.html', {
        'nav': _nav(request.user),
        'tests': test_list
    }, context_instance=RequestContext(request))


def top_indv(request, division):
    if not request.user.is_staff:
        return HttpResponseRedirect(reverse('proctor_login'))
    if is_coach(request.user):
        return is_coach_error()
    bool_div = False
    if (int(division) == 1):
        bool_div = True


    participants = _get_top_participants(is_div_a = bool_div)
    return render_to_response('list.html', {
        'nav': _nav(request.user),
        'is_team' : False,
        'is_result' : True,
        'list' : participants
    }, context_instance=RequestContext(request))


def indv_final(request, division):
    if not request.user.is_staff:
        return HttpResponseRedirect(reverse('proctor_login'))
    if is_coach(request.user):
        return is_coach_error()
    bool_div = False
    if (int(division) == 1):
        bool_div = True


    participants = _get_top_participants(is_div_a = bool_div)
    return render_to_response('list.html', {
        'nav': _nav(request.user),
        'is_team' : False,
        'is_result' : True,
        'list' : participants
    }, context_instance=RequestContext(request))


def top_team(request, division):
    if not request.user.is_staff:
        return HttpResponseRedirect(reverse('proctor_login'))
    if is_coach(request.user):
        return is_coach_error()
    bool_div = False
    if (int(division) == 1):
        bool_div = True

    participants = _get_top_teams(is_div_a = bool_div)
    return render_to_response('list.html', {
        'nav': _nav(request.user),
        'is_team' : True,
        'is_result' : False,
        'list' : participants,
    }, context_instance=RequestContext(request))


def top_test(request, test_id):
    if not request.user.is_staff:
        return HttpResponseRedirect(reverse('proctor_login'))

    if is_coach(request.user):
        return is_coach_error()

    participants = _get_top_participants_by_test(test_id)
    return render_to_response('list.html', {
        'nav': _nav(request.user),
        'is_team' : False,
        'is_result' : False,
        'list' : participants
    }, context_instance=RequestContext(request))


def _get_top_teams(is_div_a):
    list = Team.objects.filter(school__competition_year = settings.REGISTRATION_YEAR, competing=True)
    if is_div_a:
        list = list.filter(division = 'A')
    else:
        list = list.filter(division = 'B')
    return list.select_related('school').order_by('-weighted_score')


def _get_top_participants(is_div_a):
    list = Participant.objects.filter(team__school__competition_year = settings.REGISTRATION_YEAR)
    if is_div_a:
        list = list.filter(team__division = 'A')
    else:
        list = list.filter(team__division = 'B')
    return list.select_related('team__school').order_by('-weighted_score')


def _get_top_participants_by_test(test_id):
    list = Result.objects.filter(test__id=test_id)
    return list.select_related('participant__team__school', 'test').order_by("-raw_score")

