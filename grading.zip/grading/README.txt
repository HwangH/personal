Grading models:

    Proctor, represents a PUMaC proctor who can input scores.

    Result, the result of a individual test: 
        Result.participant
        Result.test
        Result.raw_score 
        Result.normalized_score #is dict of score under different normalizations
        Result.save() #runs Result.grade() which computes the raw_score of a Result object.
        
    Test, a model for an individual test.
        Test.competition_year #(we use this freq to iterate over tests from this year)
        Test.raw_scores 
        Test.answer_count #(currently unused. I've hardcoded 8 wherever we need the number of questions)
        Test.correctAnswer #is a list of CharField objects of the correct answers for the test
        Test.values #is a list of DecimalField objects that represent the weighted score of each problem.
___________________________________
Registration models:

    Team
        Team.power_round_score #is raw power round score.
        Team.team_round_score #is raw team round score.
        Team.individual_total #is sum of individual(.3) components.
        Team.weighted_score #is normalization of Team.individual_total with .5 (+power + team)
        
    Participant
        Participant.weighted_score #is the normalized aggregate of their two normalized individual tests. It is normalized w/ respect to the individual desired average
        Participant.final_score #is the raw individual finals score (if they took)

___________________________________
How the grading actually works:
    For any score (eg, Algebra A division scores, Team round scores, Individual Finals, etc), instead of taking that score and 
    summing, we normalize the scores of that type. For example, we normalize all the Algebra A division scores. (For more 
    information on how we normalize, see the google doc linked in tech meeting log.) So the biggest problem is essentially taking 
    a list of scores, and normalizing whenever we need to. This is accomplished in this way: we keep a dictionary of scores.
    key: (some test indicator like a Test object or string w/ the name, some number x) where x is what we want to normalize to. 
    value: (dictionary with key: participant/team. value: score). These are maintained in formulas.py

    For example, the variable "dictionaryOfTestsAndIdealNorm" has the following key: (Test object, ideal_norm (this is an int)). The 
    value of this key is a dictionary that would be like {"participant1": score1; "participant2": score2; ...}.
    The raw scores are contained under the key (Test object, -1). (Note that ideal_norms should never be negative so this is ok.)
    
    To compute a normalization of a test, we do the following. Suppose we iterate over tests, and right now, we have some variable x that
    represents a test. We want to normalize to 0.5. Then we want to create a new entry of "dictionaryOfTestsAndIdealNorm" with 
    the key "(x, 0.5)". We actually normalize by running the function formulas._normalize_list(dictionaryOfTestsAndIdealNorm[(x,-1)],0.5). 
    Note that this takes in the raw scores, and normalizes to 0.5

    (Each of the functions _normalize_list, _normalize_list_with_exponenent, _find_power, _find_HRS, _find_exp_from_top_ten are
    just some math functions that reflect the grading scheme. )






formulas.update_scores() #runs everything
    for each test: 
       compute and update the weighted individual scores
       compute the top 10 work
    for each individual: (seperate function)
        compute normalized finals scores (from Particpant.final_score) and add *2 to Participant.weighted_score
        Participant.weighted_score += sum of the top 10 normalized sums  

update_scores(test) #for an indiv test, computes the dicts of scores. 

update__scores_participants() #from above

update_scores_tests() #from above

create_normalized_scores(ideal norm) #for each indiv test, it computes Result.normalized_score[ideal norm]












